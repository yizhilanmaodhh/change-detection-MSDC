from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
#from compiler.ast import flatten
#import Image
import scipy
import cv2

class GenerationSample:
 
  def generate_sample(DIR,i1,i2,neibor_size):
    add_size = neibor_size//2
    rows,cols = i1.shape
    print (i1.shape)
    #rows_array = np.zeros((rows,add_size))
    rows_array1 = i1[:,0:add_size]
    rows_array2 = i2[:,0:add_size]

    i1 = np.hstack((rows_array1,i1,rows_array1))
    i2 = np.hstack((rows_array2,i2,rows_array2))
    #di = np.hstack((rows_array_di,di,rows_array_di))

    #cols_array = np.zeros((add_size,cols + neibor_size))
    cols_array1 = i1[0:add_size,:]
    cols_array2 = i2[0:add_size,:]
    #cols_array_di = di[0:add_size,:]
    print (cols_array2.shape)
    #print(a)
    i1 = np.vstack((cols_array1,i1,cols_array1))
    i2 = np.vstack((cols_array2,i2,cols_array2))
    #di = np.vstack((cols_array_di,di,cols_array_di))

    n = 0
    train_x_i1 = np.zeros((1,neibor_size*neibor_size))
    train_x_i2 = np.zeros((1,neibor_size*neibor_size))
    #train_x_di = np.zeros((1,neibor_size*neibor_size))
    neibor_zeros = np.zeros((neibor_size,neibor_size))
    #-----------------------------70*7---------------------
    n = 0
    for i in range (0,rows):
      for j in range (0,cols):
          neibor1 = i1[i:neibor_size+i,j:neibor_size+j]
          neibor2 = i2[i:neibor_size+i,j:neibor_size+j]

          patch1 = Image.fromarray(neibor1.astype(np.uint8))
          patch2 = Image.fromarray(neibor2.astype(np.uint8))
      
          patch1.save(DIR+"/i1_%s/%s_%04d.jpg" % (neibor_size,"c",n))
          patch2.save(DIR+"/i2_%s/%s_%04d.jpg" % (neibor_size,"c",n))
          
          n= n+1
    print (n)

