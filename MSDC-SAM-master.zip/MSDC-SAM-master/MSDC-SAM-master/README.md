# A PyTorch implementation of [**A multiscale self-attention deep clustering for change detection in SAR images**] 

## in *IEEE Transactions on Geoscience and Remote Sensing*, 2021. Available in Early Access.

by Huihui Dong, Wenping Ma, Licheng Jiao, Fang Liu, Lingling Li.

Pytorch version=1.1.0 (Very important to our method beacuase the effect of randomly initialized parameters):
#you can directly use the following command to install
# CUDA 10.0
conda install pytorch==1.1.0 torchvision==0.3.0 cudatoolkit=10.0 -c pytorch

Run the code:
1. run:

```
$ dash main.sh
```
#Train the networks and obtain the detection result

