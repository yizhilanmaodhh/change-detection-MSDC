# Copyright (c) 2017-present, Facebook, Inc.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
#
import time

import faiss
import numpy as np
from PIL import Image
from PIL import ImageFile
from scipy.sparse import csr_matrix, find
import torch
import torch.utils.data as data
import torchvision.transforms as transforms
from skfuzzy.cluster import cmeans
import matplotlib.pyplot as plt
from  sklearn.cluster import AgglomerativeClustering
import scipy.signal as signal
from sklearn.cluster import SpectralClustering
from pyclust import KMedoids

from skimage.segmentation import slic,mark_boundaries
from scipy.cluster.vq import vq,whiten
from sklearn.cluster import KMeans
ImageFile.LOAD_TRUNCATED_IMAGES = True

__all__ = ['PIC', 'Kmeans', 'cluster_assign', 'arrange_clustering']


def pil_loader(path):
    """Loads an image.
    Args:
        path (string): path to image file
    Returns:
        Image
    """
    with open(path, 'rb') as f:
        img = Image.open(f)
        return img.convert('RGB')


class ReassignedDataset(data.Dataset):
    """A dataset where the new images labels are given in argument.
    Args:
        image_indexes (list): list of data indexes
        pseudolabels (list): list of labels for each data
        dataset (list): list of tuples with paths to images
        transform (callable, optional): a function/transform that takes in
                                        an PIL image and returns a
                                        transformed version
    """
    #print ('ReassignedDataset-------------------')
    def __init__(self, image_indexes, pseudolabels, dataset, transform=None):
        #print ('ReassignedDataset:__init__-------------------')
        self.imgs = self.make_dataset(image_indexes, pseudolabels, dataset)
        self.transform = transform
        #.pseudolabel = self.__getitem__(index)

    def make_dataset(self, image_indexes, pseudolabels, dataset):
        print ('ReassignedDataset:make_dataset-------------------')
        label_to_idx = {label: idx for idx, label in enumerate(set(pseudolabels))}
        images = []
        for j, idx in enumerate(image_indexes):
            path1 = dataset[idx][0]
            path2 = dataset[idx][1]
            path3 = dataset[idx][2]
            path4 = dataset[idx][3]
            path5 = dataset[idx][4]
            path6 = dataset[idx][5]
            pseudolabel = label_to_idx[pseudolabels[j]]
            images.append((path1,path2,path3,path4,path5,path6, pseudolabel))
        return images

    def __getitem__(self, index):
        """
        Args:
            index (int): index of data
        Returns:
            tuple: (image, pseudolabel) where pseudolabel is the cluster of index datapoint
        """
        #print ('ReassignedDataset:__getitem__-------------------')
        path1, path2,path3, path4,path5, path6, pseudolabel = self.imgs[index]
        img1 = pil_loader(path1)
        img2 = pil_loader(path2)
        img3 = pil_loader(path3)
        img4 = pil_loader(path4)
        img5 = pil_loader(path5)
        img6 = pil_loader(path6)
        if self.transform is not None:
            img1 = self.transform(img1)
            img2 = self.transform(img2)
            img3 = self.transform(img3)
            img4 = self.transform(img4)
            img5 = self.transform(img5)
            img6 = self.transform(img6)
        return img1,img2,img3,img4,img5,img6,pseudolabel

    def __len__(self):
        #print ('ReassignedDataset:__len__-------------------')
        return len(self.imgs)


def preprocess_features(npdata, pca=50):
    """Preprocess an array of features.
    Args:
        npdata (np.array N * ndim): features to preprocess
        pca (int): dim of output
    Returns:
        np.array of dim N * pca: data PCA-reduced, whitened and L2-normalized
    """
    #print ('preprocess_features-------------------')
    _, ndim = npdata.shape
    npdata =  npdata.astype('float32')

    # Apply PCA-whitening with Faiss
    mat = faiss.PCAMatrix (ndim, pca, eigen_power= 0) # -0.01, -1, -0.05 
    mat.train(npdata)
    assert mat.is_trained
    npdata = mat.apply_py(npdata)

    # L2 normalization
    row_sums = np.linalg.norm(npdata, axis=1)
    npdata = npdata / row_sums[:, np.newaxis]

    return npdata


def make_graph(xb, nnn):
    """Builds a graph of nearest neighbors.
    Args:
        xb (np.array): datafrom  skldouble'earn.cluster import DBSCAN
        nnn (int): number of nearest neighbors
    Returns:
        list: for each data the list of ids to its nnn nearest neighbors
        list: for each data the list of distances to its nnn NN
    """
    #print ('make_graph-------------------')
    N, dim = xb.shape

    # we need only a StandardGpuResources per GPU
    #res = faiss.StandardGpuResources()

    # L2
    #flat_config = faiss.GpuIndexFlatConfig()
    #flat_config.device = int(torch.cuda.device_count()) - 1
    index = faiss.IndexFlatL2(dim)
    index.add(xb)
    D, I = index.search(xb, nnn + 1)
    return I, D


def cluster_assign(images_lists, dataset):
    """Creates a dataset from clustering, with clusters as labels.
    Args:
        images_lists (list of list): for each cluster, the list of image indexes
                                    belonging to this cluster
        dataset (list): initial dataset
    Returns:d
        ReassignedDataset(torch.utils.data.Dataset): a dataset with clusters as
                                                     labels
    """
    #print ('cluster_assign-------------------')
    assert images_lists is not None
    pseudolabels = []
    image_indexes = []
    for cluster, images in enumerate(images_lists):
        image_indexes.extend(images)
        pseudolabels.extend([cluster] * len(images))

    normalize = transforms.Normalize(mean=[0.5, 0.5, 0.5],
                                     std=[0.5, 0.5, 0.5])
    t = transforms.Compose([#transforms.RandomResizedCrop(9),
                            #transforms.RandomHorizontalFlip(),
                            transforms.ToTensor(),
                            normalize
                            ])

    return ReassignedDataset(image_indexes, pseudolabels, dataset, t)


def run_kmeans(x, i3,nmb_cluster, epoch,lr,verbose=False):
    """Runs kmeans on 1 GPU.
    Args:
        x: data
        nmb_clusters (int): number of clusters
    Returns:data=whiten(points
        list: ids of data in each cluster
    """
    rows,cols = i3.shape
    x=whiten(x)
    x_temp = x #np.sum(x,1)

    x = np.sum(x,1)
    x= x.reshape((x.shape[0],1))
    #x = x_temp
 
    #----------------使用Kmeans++---------------
    estimator1 = KMeans(n_clusters=nmb_cluster,init='k-means++')#构造聚类器
    estimator1.fit(x_temp)#聚类
    I = estimator1.labels_
    
    estimator2 = KMeans(n_clusters=2,init='k-means++')#构造聚类器
    estimator2.fit(x_temp)#聚类
    I_2 = estimator2.labels_
    print (I.shape)
    #-------------end--------------
    

    clus_centroid = 0
    other_name = "octave_best"
    #calcu_changemap(x,"cf_"+other_name,epoch,lr,nmb_cluster,clus_centroid,0.00,0.00,i3)

    print ("-------------------------------I_2--------------------------------------")
    
    kappa0 = kappa(I_2.reshape(i3.shape), i3)
    kappa1 = kappa(np.abs(1-I_2.reshape(i3.shape)), i3)
    
    calcu_changemap(I_2,"cr2_"+other_name,epoch,lr,nmb_cluster,clus_centroid,kappa0,kappa1,i3)
    #calcu_changemap(I,"cr_"+other_name,epoch,lr,nmb_cluster,clus_centroid,kappa0,kappa1,i3)"""

    print ("---------------------------------after  median filter3--------------------------------------")
    I_2_filter = signal.medfilt(I_2.reshape(i3.shape),kernel_size=3) #二维中值滤波 np.float32(I_2*255)

    kappa0 = kappa(I_2_filter, i3)
    kappa1 = kappa(np.abs(1-I_2_filter), i3)

    if kappa0 > 0:
       kappa_save = kappa0
    else:
       kappa_save = kappa1
    calcu_changemap(I_2_filter,"cr2_3after filter"+other_name,epoch,lr,nmb_cluster,clus_centroid,kappa0,kappa1,i3)
    
    I = I.reshape(rows*cols ,1)
    
    return [int(n[0]) for n in I],kappa_save,I # losses[-1]

def kappa(TI, RI): #testData表示要计算的数据，k表示数据矩阵的是k*k的
    m,n = TI.shape
    #将图像转化为列向量
    
    TN = (RI==0) & (TI==0)
    TN = float(np.sum(TN==True))

    TP = (RI!=0) & (TI!=0)
    TP = float(np.sum(TP==True))

    FP = (RI==0) & (TI!=0)
    FP = float(np.sum(FP==True))

    FN = (RI!=0) & (TI==0)
    FN = float(np.sum(FN==True))

    Nc = FN + TP
    Nu = FP + TN
    OE = FP + FN;
    PRA = (TP+TN)/(m*n);
    PRE = ((TP+FP)*Nc+(FN+TN)*Nu)/(m*n)**2;
    #计算相同的比率KC0.6013
    KC = (PRA-PRE)/(1-PRE)
    print ('===evaluate====\n'
           'TN:{0} '
           'TP:{1} '
           'FP:{2} '
           'FN:{3} '
           'OE:{4} '
           'KC:{5} '.format(TN,TP,FP,FN,OE,KC))
    return KC

def calcu_changemap(B,temp,epoch,lr,nmb_cluster,clus_centroid,kappa0,kappa1,i1): 
    print ('calcu_changemap------')
    rows,cols = i1.shape
    print (np.max(B))
    print (np.min(B))
    #i1 = i1.T
    B_labels = B.reshape(i1.shape)
    max_x= np.max(B_labels)
    min_x= np.min(B_labels)
    B_labels = (B_labels - min_x)/(max_x-min_x)*255
    
    print ('io===============')
    #dst.save("/home/donghuihui/Pytorch/%s_%s.jpg" % ('rgb',temp)) 
    B_labels = Image.fromarray(B_labels.astype('uint8'))
    #dst  =color.label2rgb(B_labels)
    #io.imshow(dst)
    #B_labels = skimage.img_as_float(B_labels).dtype
    B_labels.save("./result_save/SAM/c%s_%s_%s_%s_%s_%.4f_%.4f.png" % (nmb_cluster,temp,epoch,lr,nmb_cluster,kappa0,kappa1))    

def arrange_clustering(images_lists):
    #print ('arrange_clustering-------------------')
    pseudolabels = []
    image_indexes = []
    for cluster, images in enumerate(images_lists):
        image_indexes.extend(images)
        pseudolabels.extend([cluster] * len(images))
    indexes = np.argsort(image_indexes)
   
    #print (pseudolabels)
    return np.asarray(pseudolabels)[indexes]


class Kmeans:
    #print ('Kmeans:-------------------')
    def __init__(self, k):
        print ('Kmeans:__init__-------------------')
        self.k = k

    def cluster(self, data, label, epoch,lr,verbose=False):
        """Performs k-means clustering.
            Args:
                x_data (np.array N * dim): data to cluster
        """
        print ('Kmeans:cluster-------------------')
        end = time.time()

        # PCA-reducing, whitening and L2-normalization
        #data = preprocess_features(data)
        # xb[np.isnan(xb)] = 0
        #xb[np.isinf(xb)] = 1
       
        #print (xb.shape)
        # cluster the data
        I,acc,I_array= run_kmeans(data,label,self.k, epoch,lr,verbose)
        
        self.images_lists = [[] for i in range(self.k)]
       
        for i in range(len(data)):
           self.images_lists[I[i]].append(i)

        if verbose:
            print('k-means time: {0:.0f} s'.format(time.time() - end))

        return acc


def make_adjacencyW(I, D, sigma):
    """Create adjacency matrix with a Gaussian kernel.
    Args:
        I (numpy array): for each vertex the ids to its nnn linked vertices
                  + first column of identity.
        D (numpy array): for each data the l2 distances to its nnn linked vertices
                  + first column of zeros.
        sigma (float): Bandwith of the Gaussian kernel.

    Returns:
        csr_matrix: affinity matrix of the graph.
    """
    print ('make_adjacencyW-------------------')
    V, k = I.shape
    k = k - 1
    indices = np.reshape(np.delete(I, 0, 1), (1, -1))
    indptr = np.multiply(k, np.arange(V + 1))

    def exp_ker(d):
        return np.exp(-d / sigma**2)

    exp_ker = np.vectorize(exp_ker)
    res_D = exp_ker(D)
    data = np.reshape(np.delete(res_D, 0, 1), (1, -1))
    adj_matrix = csr_matrix((data[0], indices[0], indptr), shape=(V, V))
    return adj_matrix


def run_pic(I, D, sigma, alpha):
    """Run PIC algorithm"""
    print ('run_pic-------------------')
    a = make_adjacencyW(I, D, sigma)
    graph = a + a.transpose()
    cgraph = graph
    nim = graph.shape[0]

    W = graph
    t0 = time.time()

    v0 = np.ones(nim) / nim

    # power iterations
    v = v0.astype('float32')

    t0 = time.time()
    dt = 0
    for i in range(200):
        vnext = np.zeros(nim, dtype='float32')

        vnext = vnext + W.transpose().dot(v)

        vnext = alpha * vnext + (1 - alpha) / nim
        # L1 normalize
        vnext /= vnext.sum()
        v = vnext

        if (i == 200 - 1):
            clust = find_maxima_cluster(W, v)


    i3 = np.array(Image.open("ref.bmp").convert('L'))
    rows,cols = i3.shape
    clus_centroid = 0
    #save DI
    #x_temp = np.sum(x,1)
    #x_temp= x_temp.reshape((rows*cols,1))

    #att1 f:(10,1,1,1) d:avg(2,2)(20,3,1,1)(20*2*2,68,2)drop0.1
    #att1 f:(10,1,1,0) d:avg(3,1)(120,1,1,1)(120*1*1,68,2)
    #att1 f:(16,1,1,1) d:(16,3,1,1)avg(2,2)(32,2,1,1)(32*3*3,256,84,2)
    commen_file = 'net-main+difference'
    calcu_changemap(x_temp,"cf_"+commen_file,epoch,lr,nmb_cluster,clus_centroid,0.00,0.00)
    kappa0 = kappa(clust.reshape(i3.shape), i3)
    kappa1 = kappa(np.abs(1-clust.reshape(i3.shape)), i3)
    calcu_changemap(clust,"cr_"+commen_file,0,0,0,0,kappa0,kappa1)

    return [int(i) for i in clust]


def find_maxima_cluster(W, v):
    print ('find_maxima_cluster-------------------')
    n, m = W.shape
    assert (n == m)
    assign = np.zeros(n)
    # for each node
    pointers = list(range(n))
    for i in range(n):
        best_vi = 0
        l0 = W.indptr[i]
        l1 = W.indptr[i + 1]
        for l in range(l0, l1):
            j = W.indices[l]
            vi = W.data[l] * (v[j] - v[i])
            if vi > best_vi:
                vi = best_vi
                pointers[i] = j
    n_clus = 0
    cluster_ids = -1 * np.ones(n)
    for i in range(n):
        if pointers[i] == i:
            cluster_ids[i] = n_clus
            n_clus = n_clus + 1
    for i in range(n):
        # go from pointers to pointers starting from i until reached a local optim
        current_node = i
        while pointers[current_node] != current_node:
            current_node = pointers[current_node]

        assign[i] = cluster_ids[current_node]
        assert (assign[i] >= 0)
    return assign


class PIC():
    """Class to perform Power Iteration Clustering on a graph of nearest neighbors.
        Args:
            args: for consistency with k-means init
            sigma (float): bandwith of the Gaussian kernel (default 0.2)
            nnn (int): number of nearest neighbors (default 5)
            alpha (float): parameter in PIC (default 0.001)
            distribute_singletons (bool): If True, reassign each singleton to
                                      the cluster of its closest non
                                      singleton nearest neighbors (up to nnn
                                      nearest neighbors).
        Attributes:
            images_lists (list of list): for each cluster, the list of image indexes
                                         belonging to this cluster
    """

    def __init__(self, args=None, sigma=0.2, nnn=5, alpha=0.001, distribute_singletons=True):
        self.sigma = sigma
        self.alpha = alpha
        self.nnn = nnn
        self.distribute_singletons = distribute_singletons

    def cluster(self, data, verbose=False):
        end = time.time()

        # preprocess the data
        xb = preprocess_features(data)

        # construct nnn graph
        I, D = make_graph(xb, self.nnn)

        # run PIC
        clust = run_pic(I, D, self.sigma, self.alpha)
        images_lists = {}
        for h in set(clust):
            images_lists[h] = []
        for data, c in enumerate(clust):
            images_lists[c].append(data)

        # allocate singletons to clusters of their closest NN not singleton
        if self.distribute_singletons:
            clust_NN = {}
            for i in images_lists:
                # if singleton
                if len(images_lists[i]) == 1:
                    s = images_lists[i][0]
                    # for NN
                    for n in I[s, 1:]:
                        # if NN is not a singleton
                        if not len(images_lists[clust[n]]) == 1:
                            clust_NN[s] = n
                            break
            for s in clust_NN:
                del images_lists[clust[s]]
                clust[s] = clust[clust_NN[s]]
                images_lists[clust[s]].append(s)

        self.images_lists = []
        for c in images_lists:
            self.images_lists.append(images_lists[c])

        if verbose:
            print('pic time: {0:.0f} s'.format(time.time() - end))
        return 0

