import math

import numpy as np
import torch
import torch.nn as nn

__all__ = [ 'AlexNet', 'alexnet']
class OctaveConv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, alpha=0.5, stride=1, padding=1, dilation=1,
                 groups=1, bias=False):
        super(OctaveConv, self).__init__()
        kernel_size = kernel_size[0]
        self.h2g_pool = nn.AvgPool2d(kernel_size=(2, 2), stride=2)
        self.upsample = torch.nn.Upsample(scale_factor=2, mode='nearest')
        self.stride = stride
        self.l2l = torch.nn.Conv2d(int(alpha * in_channels), int(alpha * out_channels),
                                   kernel_size, 1, padding, dilation, groups, bias)
        self.l2h = torch.nn.Conv2d(int(alpha * in_channels), out_channels - int(alpha * out_channels),
                                   kernel_size, 1, padding, dilation, groups, bias)
        self.h2l = torch.nn.Conv2d(in_channels - int(alpha * in_channels), int(alpha * out_channels),
                                   kernel_size, 1, padding, dilation, groups, bias)
        self.h2h = torch.nn.Conv2d(in_channels - int(alpha * in_channels),
                                   out_channels - int(alpha * out_channels),
                                   kernel_size, 1, padding, dilation, groups, bias)

    def forward(self, x):
        X_h, X_l = x

        if self.stride ==2:
            X_h, X_l = self.h2g_pool(X_h), self.h2g_pool(X_l)

        X_h2l = self.h2g_pool(X_h)

        X_h2h = self.h2h(X_h)
        X_l2h = self.l2h(X_l)

        X_l2l = self.l2l(X_l)
        X_h2l = self.h2l(X_h2l)
        
        X_l2h = self.upsample(X_l2h)

        #print ('h:',X_l2h.shape,X_h2h.shape)
        #print ('l:',X_h2l.shape,X_l2l.shape)

        X_h = X_l2h + X_h2h
        X_l = X_h2l + X_l2l

        return X_h, X_l


class FirstOctaveConv(nn.Module):
    def __init__(self, in_channels, out_channels,kernel_size, alpha=0.5, stride=1, padding=1, dilation=1,
                 groups=1, bias=False):
        super(FirstOctaveConv, self).__init__()
        self.stride = stride
        kernel_size = kernel_size[0]
        self.h2g_pool = nn.AvgPool2d(kernel_size=(2, 2), stride=2)
        self.h2l = torch.nn.Conv2d(in_channels, int(alpha * out_channels),
                                   kernel_size, 1, padding, dilation, groups, bias)
        self.h2h = torch.nn.Conv2d(in_channels, out_channels - int(alpha * out_channels),
                                   kernel_size, 1, padding, dilation, groups, bias)

    def forward(self, x):
        if self.stride ==2:
            x = self.h2g_pool(x)

        X_h2l = self.h2g_pool(x)
        X_h = x
        X_h = self.h2h(X_h)
        X_l = self.h2l(X_h2l)

        return X_h, X_l


class LastOctaveConv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, alpha=0.5, stride=1, padding=1, dilation=1,
                 groups=1, bias=False):
        super(LastOctaveConv, self).__init__()
        self.stride = stride
        kernel_size = kernel_size[0]
        self.h2g_pool = nn.AvgPool2d(kernel_size=(2,2), stride=2)

        self.l2h = torch.nn.Conv2d(int(alpha * in_channels), out_channels,
                                   kernel_size, 1, padding, dilation, groups, bias)
        self.h2h = torch.nn.Conv2d(in_channels - int(alpha * in_channels),
                                   out_channels,
                                   kernel_size, 1, padding, dilation, groups, bias)
        self.upsample = torch.nn.Upsample(scale_factor=2, mode='nearest')

    def forward(self, x):
        X_h, X_l = x

        if self.stride ==2:
            X_h, X_l = self.h2g_pool(X_h), self.h2g_pool(X_l)

        X_l2h = self.l2h(X_l)
        X_h2h = self.h2h(X_h)
        X_l2h = self.upsample(X_l2h)
        
        X_h = X_h2h + X_l2h

        return X_h


class OctaveCBR(nn.Module):
    def __init__(self,in_channels, out_channels, kernel_size=(3,3),alpha=0.5, stride=1, padding=1, dilation=1,
                 groups=1, bias=False, norm_layer=nn.BatchNorm2d):
        super(OctaveCBR, self).__init__()
        self.conv = OctaveConv(in_channels,out_channels,kernel_size, alpha, stride, padding, dilation, groups, bias)
        self.bn_h = norm_layer(int(out_channels*(1-alpha)))
        self.bn_l = norm_layer(int(out_channels*alpha))
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x_h, x_l = self.conv(x)
        x_h = self.relu(self.bn_h(x_h))
        x_l = self.relu(self.bn_l(x_l))
        #print (x_h.shape,x_l.shape)
        return x_h, x_l


class OctaveCB(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=(3,3), alpha=0.5, stride=1, padding=1, dilation=1,
                 groups=1, bias=False, norm_layer=nn.BatchNorm2d):
        super(OctaveCB, self).__init__()
        self.conv = OctaveConv(in_channels, out_channels, kernel_size, alpha, stride, padding, dilation,
                               groups, bias)
        self.bn_h = norm_layer(int(out_channels * (1 - alpha)))
        self.bn_l = norm_layer(int(out_channels * alpha))

    def forward(self, x):
        x_h, x_l = self.conv(x)
        x_h = self.bn_h(x_h)
        x_l = self.bn_l(x_l)
        return x_h, x_l


class FirstOctaveCBR(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=(3,3),alpha=0.5, stride=1, padding=1, dilation=1,
                 groups=1, bias=False,norm_layer=nn.BatchNorm2d):
        super(FirstOctaveCBR, self).__init__()
        self.conv = FirstOctaveConv(in_channels,out_channels,kernel_size, alpha,stride,padding,dilation,groups,bias)
        self.bn_h = norm_layer(int(out_channels * (1 - alpha)))
        self.bn_l = norm_layer(int(out_channels * alpha))
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x_h, x_l = self.conv(x)
        x_h = self.relu(self.bn_h(x_h))
        x_l = self.relu(self.bn_l(x_l))
        return x_h, x_l


class LastOCtaveCBR(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=(3,3), alpha=0.5, stride=1, padding=1, dilation=1,
                 groups=1, bias=False, norm_layer=nn.BatchNorm2d):
        super(LastOCtaveCBR, self).__init__()
        self.conv = LastOctaveConv(in_channels, out_channels, kernel_size, alpha, stride, padding, dilation, groups, bias)
        self.bn_h = norm_layer(out_channels)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x_h = self.conv(x)
        x_h = self.relu(self.bn_h(x_h))
    
        return x_h


class FirstOctaveCB(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=(3,3), alpha=0.5,stride=1, padding=1, dilation=1,
                 groups=1, bias=False, norm_layer=nn.BatchNorm2d):
        super(FirstOctaveCB, self).__init__()
        self.conv = FirstOctaveConv(in_channels,out_channels,kernel_size, alpha,stride,padding,dilation,groups,bias)
        self.bn_h = norm_layer(int(out_channels * (1 - alpha)))
        self.bn_l = norm_layer(int(out_channels * alpha))
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x_h, x_l = self.conv(x)
        x_h = self.bn_h(x_h)
        x_l = self.bn_l(x_l)
        return x_h, x_l


class LastOCtaveCB(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, alpha=0.5, stride=1, padding=1, dilation=1,
                 groups=1, bias=False, norm_layer=nn.BatchNorm2d):
        super(LastOCtaveCB, self).__init__()
        self.conv = LastOctaveConv( in_channels, out_channels, kernel_size, alpha, stride, padding, dilation, groups, bias)
        self.bn_h = norm_layer(out_channels)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x_h = self.conv(x)
        x_h = self.bn_h(x_h)
        return x_h

class Self_Attn(nn.Module):
    """ Self attention Layer"""
    def __init__(self,in_dim,activation):
        super(Self_Attn,self).__init__()
        self.chanel_in = in_dim
        self.activation = activation
        
        self.query_conv = nn.Conv2d(in_channels = in_dim , out_channels = in_dim//2, kernel_size= 1)
        self.key_conv = nn.Conv2d(in_channels = in_dim , out_channels = in_dim//2, kernel_size= 1)
        self.value_conv = nn.Conv2d(in_channels = in_dim , out_channels = in_dim , kernel_size= 1)
        self.gamma = nn.Parameter(torch.zeros(1))
        self.gamma1 = nn.Parameter(torch.ones(1))
        self.gamma2 = nn.Parameter(torch.ones(1))
        self.gamma3 = nn.Parameter(torch.ones(1))
        self.softmax  = nn.Softmax(dim=-1) #
    def forward(self,x1,x2,x3,index):
        """
            inputs :
                x : input feature maps( B X C X W X H)
            returns :
                out : self attention value + input feature 
                attention: B X N X N (N is Width*Height)
        """
        m_batchsize,C,width ,height = x1.size()
        proj_query  = self.query_conv(x1).view(m_batchsize,-1,width*height).permute(0,2,1) # B X CX(N)
        proj_key =  self.key_conv(x2).view(m_batchsize,-1,width*height) # B X C x (*W*H)
        energy =  torch.bmm(proj_query,proj_key) # transpose check
        attention = self.softmax(energy) # BX (N) X (N) 
        proj_value = self.value_conv(x3).view(m_batchsize,-1,width*height) # B X C X N

        out = torch.bmm(proj_value,attention.permute(0,2,1) )
        out = out.view(m_batchsize,C,width,height)
        if index == 1:
           out = self.gamma*out + self.gamma1* x1 + self.gamma2*x2 + self.gamma3*x3
           #out = self.gamma*out + x1 + x2 + x3
        else:
           out = self.gamma*out + x3
        #out = self.gamma*out + x1 + x2 + x3
        #out = self.gamma*out + self.gamma1* x1 + self.gamma2*x2 + self.gamma3*x3
        return out,attention


class AlexNet(nn.Module):
    def __init__(self, features1, features2,features3,num_classes, sobel):
        super(AlexNet, self).__init__()
        self.features1 = features1
        self.features2 = features2
        self.features3 = features3
        self.attn1 = Self_Attn(8, 'relu')
         
        self.attn2 = Self_Attn(32,  'relu')
     
        #self.gamma11 = nn.Parameter(torch.ones(1))
        #self.gamma22 = nn.Parameter(torch.ones(1))
        #self.gamma33 = nn.Parameter(torch.ones(1))

        self.ocb_f1 = FirstOctaveCBR(8, 16, kernel_size=(3, 3),alpha=0.75,padding=1,norm_layer=nn.BatchNorm2d).cuda()

        self.ocb_fm1 = OctaveCBR(16, 96, kernel_size=(2, 2),alpha=0.75, padding=1,norm_layer=nn.BatchNorm2d).cuda()

        self.ocb_fm2 = OctaveCBR(96, 128, kernel_size=(3, 3),alpha=0.75,padding=1,norm_layer=nn.BatchNorm2d).cuda()

        self.ocb_d1 = OctaveCBR(128, 64, kernel_size=(3, 3),alpha=0.75, padding=1,norm_layer=nn.BatchNorm2d).cuda()
        self.ocb_dl = LastOCtaveCBR(64, 32, kernel_size=(1, 1),alpha=0.75,padding=0,norm_layer=nn.BatchNorm2d).cuda()

        self.classifier = nn.Sequential(#nn.Dropout(0.05),
                            nn.Linear(32 * 8 * 8,32),
                            nn.ReLU(inplace=True))
                           
      
        self.top_layer = nn.Linear(32, num_classes)
        self._initialize_weights()

        if sobel:
            grayscale = nn.Conv2d(3, 1, kernel_size=1, stride=1, padding=0)
            grayscale.weight.data.fill_(1.0 / 3.0)
            grayscale.bias.data.zero_()
            sobel_filter = nn.Conv2d(1, 2, kernel_size=3, stride=1, padding=1)
            sobel_filter.weight.data[0, 0].copy_(
                torch.FloatTensor([[1, 0, -1], [2, 0, -2], [1, 0, -1]])
            )
            sobel_filter.weight.data[1, 0].copy_(
                torch.FloatTensor([[1, 2, 1], [0, 0, 0], [-1, -2, -1]])
            )
            sobel_filter.bias.data.zero_()
            self.sobel = nn.Sequential(grayscale, sobel_filter)
            for p in self.sobel.parameters():
                p.requires_grad = False
        else:
            self.sobel = None
    
    
    def forward(self, x1_3,x2_3,x1_5,x2_5,x1_7,x2_7):
        #if self.sobel:
          #  x = self.sobel(x)
        
        x1_3 = self.features1(x1_3)
        x2_3 = self.features1(x2_3)
        x1_5 = self.features2(x1_5)
        x2_5 = self.features2(x2_5)
        x1_7 = self.features3(x1_7)
        x2_7 = self.features3(x2_7)
  
        #print (x1_3.shape,x1_5.shape,x1_7.shape)
        #print (a)

        out1,p1 = self.attn1(x1_3,x1_5,x1_7,1)	#SAM
        out2,p2 = self.attn1(x2_3,x2_5,x2_7,1)

        #out1= x1_3*self.gamma11+ x1_5*self.gamma22+x1_7*self.gamma33 #AM
        #out2= x2_3*self.gamma11+ x2_5*self.gamma22+x2_7*self.gamma33

        #out1= x1_3+ x1_5+x1_7 #FM
        #out2= x2_3+ x2_5+x2_7

        x1_h, x1_l = self.ocb_f1(out1)
        x2_h, x2_l= self.ocb_f1(out2)
        
   
        #print ("out1---------------------")
        #print (x1_h.shape,x1_l.shape)
        #print (x2_h.shape,x2_l.shape)
         
        x1 = x1_h, x1_l
        x2 = x2_h, x2_l

        x1_h, x1_l = self.ocb_fm1(x1)
        x2_h, x2_l = self.ocb_fm1(x2)

        #print ("out2---------------------")
        #print (x1_h.shape,x1_l.shape)
        #print (x2_h.shape,x2_l.shape) 

        x1 = x1_h, x1_l
        x2 = x2_h, x2_l

        x1_h, x1_l = self.ocb_fm2(x1)
        x2_h, x2_l = self.ocb_fm2(x2)

        #print ("out3---------------------")
        #print (x1_h.shape,x1_l.shape)
        #print (x2_h.shape,x2_l.shape) 

        difference_h = torch.sub(x1_h.pow(2),x2_h.pow(2))
        difference_h = difference_h.pow(2)
  
        difference_l = torch.sub(x1_l.pow(2),x2_l.pow(2))
        difference_l = difference_l.pow(2)
        
        difference_out = difference_h,difference_l
        #print ("difference_out---------------------")
        #print (difference_h.shape,difference_l.shape)
        

        d_h, d_l = self.ocb_d1(difference_out)
        #print ("difference_out---------------------")
        #print (d_h.shape,d_l.shape)
        d = d_h, d_l

        x = self.ocb_dl(d)
    
        x,p3 = self.attn2(x,x,x,2)
        x = x.view(x.size(0), 32 * 8 * 8)
       
        x = self.classifier(x)
        
        if self.top_layer:
            x = self.top_layer(x)
        return x
                         
    def _initialize_weights(self):
        for y, m in enumerate(self.modules()):
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                for i in range(m.out_channels):
                    m.weight.data[i].normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                m.weight.data.normal_(0, 0.01)
                m.bias.data.zero_()


def make_layers_features1(input_dim, bn):
   
    layers = []
    in_channels = input_dim
    cfg = {
       '2012': [(8,1,1,2)] 
    }
    for v in cfg['2012']:
        if v == 'M':
            layers += [nn.AvgPool2d(kernel_size=2, stride=2)]
        else:
            print ("conv---------------------")
            print (v[0])
            print (v[1])
            print (v[2])
            conv2d = nn.Conv2d(in_channels, v[0], kernel_size=v[1], stride=v[2], padding=v[3])
            if bn:
                layers += [conv2d, nn.BatchNorm2d(v[0]), nn.ReLU(inplace=True)]
            else:
                layers += [conv2d, nn.ReLU(inplace=True)]
            in_channels = v[0]
    return nn.Sequential(*layers)
def make_layers_features2(input_dim, bn):
   
    layers = []
    in_channels = input_dim
    cfg = {
       '2012': [(8, 3, 1,2)]
    }
    for v in cfg['2012']:
        if v == 'M':
            layers += [nn.AvgPool2d(kernel_size=2, stride=2)]
        else:
            print ("conv---------------------")
            print (v[0])
            print (v[1])
            print (v[2])
            conv2d = nn.Conv2d(in_channels, v[0], kernel_size=v[1], stride=v[2], padding=v[3])
            if bn:
                layers += [conv2d, nn.BatchNorm2d(v[0]), nn.ReLU(inplace=True)]
            else:
                layers += [conv2d, nn.ReLU(inplace=True)]
            in_channels = v[0]
    return nn.Sequential(*layers)
def make_layers_features3(input_dim, bn):
   
    layers = []
    in_channels = input_dim
    cfg = {
       '2012': [(8, 5, 1,2)]
    }
    for v in cfg['2012']:
        if v == 'M':
            layers += [nn.AvgPool2d(kernel_size=2, stride=2)]
        else:
            print ("conv---------------------")
            print (v[0])
            print (v[1])
            print (v[2])
            conv2d = nn.Conv2d(in_channels, v[0], kernel_size=v[1], stride=v[2], padding=v[3])
            if bn:
                layers += [conv2d, nn.BatchNorm2d(v[0]), nn.ReLU(inplace=True)]
            else:
                layers += [conv2d, nn.ReLU(inplace=True)]
            in_channels = v[0]
    return nn.Sequential(*layers)

def alexnet(sobel=False, bn=True, out=2):
    dim = 2 + int(not sobel)
    print ('dim=',dim)
    model = AlexNet(make_layers_features1(dim, bn=bn),make_layers_features2(dim, bn=bn),make_layers_features3(dim, bn=bn), out, sobel) 
    return model
