from torchvision import transforms, utils
from torch.utils.data import Dataset
from torch.utils.data.dataloader import DataLoader
import matplotlib.pyplot as plt
from PIL import Image
import numpy as np 
import os

def default_loader(path):
    return Image.open(path).convert('RGB')
 
 
class MyDataset(Dataset):
    def __init__(self, i3,root, transform=None, target_transform=None,loader=default_loader):
        rows,cols = i3.shape
        i3 = i3/255
        labels = i3.reshape(rows*cols,1)
        imgs = []
        for i in range(0,rows*cols): 
            #drain = irain.next() 
            #dnorain = iground.next() 
            img_file1 = os.path.join(root+"/i1_5/","c_%04d.jpg"%i) #跟上面一样，不过因为已经知道文件的取名顺序，所以拼出需要访问的文件名
            img_file2 = os.path.join(root+"/i2_5/","c_%04d.jpg"%i)
            img_file3 = os.path.join(root+"/i1_5/","c_%04d.jpg"%i) #跟上面一样，不过因为已经知道文件的取名顺序，所以拼出需要访问的文件名
            img_file4 = os.path.join(root+"/i2_5/","c_%04d.jpg"%i)
            img_file5 = os.path.join(root+"/i1_5/","c_%04d.jpg"%i) #跟上面一样，不过因为已经知道文件的取名顺序，所以拼出需要访问的文件名
            img_file6 = os.path.join(root+"/i2_5/","c_%04d.jpg"%i)
            imgs.append((img_file1,img_file2,img_file3,img_file4,img_file5,img_file6,labels[i,0]))
        self.imgs = imgs
        self.transform = transform
        self.target_transform = target_transform
        self.loader = loader
 
    def __getitem__(self, index):
        fn1,fn2,fn3,fn4,fn5,fn6, label = self.imgs[index]
        img1 = self.loader(fn1)
        img2 = self.loader(fn2)
        img3 = self.loader(fn3)
        img4 = self.loader(fn4)
        img5 = self.loader(fn5)
        img6 = self.loader(fn6)
        if self.transform is not None:
            img1 = self.transform(img1)
            img2 = self.transform(img2)
            img3 = self.transform(img3)
            img4 = self.transform(img4)
            img5 = self.transform(img5)
            img6 = self.transform(img6)
        return img1,img2,img3,img4,img5,img6,label
 
    def __len__(self):
        return len(self.imgs)
    
#根据自己定义的那个勒MyDataset来创建数据集！注意是数据集！而不是loader迭代器
#train_data=MyDataset(txt=root+'train.txt', transform=transforms.ToTensor())
#test_data=MyDataset(txt=root+'test.txt', transform=transforms.ToTensor())
