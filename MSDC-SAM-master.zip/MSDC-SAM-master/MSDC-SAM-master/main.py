# Copyright (c) 2017-present, Facebook, Inc.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
#
import argparse
import os
import pickle
import time

#import faiss
import numpy as np
from sklearn.metrics.cluster import normalized_mutual_info_score
import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.optim
import torch.utils.data
import torchvision.transforms as transforms
import torchvision.datasets as datasets
from PIL import Image
import matplotlib.pyplot as plt

import scipy.signal as signal
import clustering
import models
import mydataset
import SideWindowFilter
from deal_data_CNN import * 
from util import AverageMeter, Logger, UnifLabelSampler
#from skimage import io,color

from torch.autograd import Variable
import torch.utils.data as Data
import torchvision
from torchvision import transforms
import torch.nn.functional as F
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import matplotlib.patheffects as PathEffects
import torch.optim.lr_scheduler as lr_scheduler
import matplotlib.cm as cm
import warnings
from torch.utils.data.dataloader import DataLoader
import adabound

import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import host_subplot

parser = argparse.ArgumentParser(description='PyTorch Implementation of DeepCluster')

parser.add_argument('data', metavar='DIR', help='path to dataset')
parser.add_argument('--arch', '-a', type=str, metavar='ARCH',
                    choices=['lenet','alexnet', 'vgg16'], default='alexnet',
                    help='CNN architecture (default: lenet)')
parser.add_argument('--sobel', action='store_true', help='Sobel filtering')
parser.add_argument('--clustering', type=str, choices=['Kmeans', 'PIC'],
                    default='Kmeans', help='clustering algorithm (default: Kmeans)')

parser.add_argument('--nmb_cluster', '--k', type=int, default=15,
                    help='number of cluster for k-means (default: 2)')
parser.add_argument('--lr', default=0.01, type=float,
                    help='learning rate (default: 0.05)')
parser.add_argument('--wd', default=0.00001, type=float,
                    help='weight decay pow (default: -5)')

parser.add_argument('--reassign', type=float, default=1,
                    help="""how many epochs of training between two consecutive
                    reassignments of clusters (default: 1)""")
parser.add_argument('--workers', default=20, type=int,
                    help='number of data loading workers (default: 4)')
parser.add_argument('--epochs', type=int, default=50,
                    help='number of total epochs to run (default: 200)')
parser.add_argument('--start_epoch', default=0, type=int,
                    help='manual epoch number (useful on restarts) (default: 0)')
parser.add_argument('--batch', default=256, type=int,
                    help='mini-batch size (default: 36)')
parser.add_argument('--momentum', default=0.9, type=float, help='momentum (default: 0.9)')
parser.add_argument('--resume', default='/home/change_detection/deepcluster-master-multiscale1/test/exp/checkpoints/checkpoint_888911.0.pth.tar', type=str, metavar='PATH',
                    help='path to checkpoint (default: None)')
parser.add_argument('--checkpoints', type=int, default=2000,
                    help='how many iterations between two checkpoints (default: 25000)')
parser.add_argument('--seed', type=int, default=10, help='random seed (default: 10)')
parser.add_argument('--exp', type=str, default='exp', help='path to exp folder')
parser.add_argument('--verbose', action='store_true', help='chatty')

def SideWindowFilter_main(img):
    s = SideWindowFilter.SideWindowFilter(radius=3, iteration=1)
    #img = Image.open('lena.png').convert('L')
    print (img.shape)
    img = torch.tensor(img, dtype=torch.float)
    #print('img ori = ', img)

    print(len(img.size()))
    if len(img.size()) == 2:
        h, w = img.size()
        img = img.view(-1, 1, h, w)
    else:
        c, h, w = img.size()
        img = img.view(-1, c, h, w)
    print('img = ', img.shape)

    res = s.forward(img)

    print('res = ', res.shape)
   
    if res.size(1) == 3:
        img_res = np.transpose(np.squeeze(res.data.numpy()), (1, 2, 0))
    else:
       img_res = np.squeeze(res.data.numpy())

    #img_res = img_res.astype(np.uint8)
    return img_res

def main():
    global args
    args = parser.parse_args()

    #对数据进行 side window boxfilter,并进行逐像素样本处理
    i1 = np.array(Image.open("./dataset/Yellow River/Yellow River II-SAR/im1.bmp").convert('L'))
    i2 = np.array(Image.open("./dataset/Yellow River/Yellow River II-SAR/im2.bmp").convert('L'))
    label = np.array(Image.open("./dataset/Yellow River/Yellow River II-SAR/YR-II-ref.bmp").convert('L'))

    #1.使用side window boxfilter方法 进行降噪处理
    print ("============starting preprocessing============")
    i1 =  SideWindowFilter_main(i1)
    i2 =  SideWindowFilter_main(i2)
    
    #2.逐像素样本生成
    print ("============starting generate sample============")
    GenerationSample.generate_sample(args.data,i1,i2,3)
    GenerationSample.generate_sample(args.data,i1,i2,5)
    GenerationSample.generate_sample(args.data,i1,i2,7)

    print ('network model()-------------------')
    # fix random seeds
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    np.random.seed(args.seed)

    # CNN
    if args.verbose:
        print('Architecture: {}'.format(args.arch))
    model = models.__dict__[args.arch](sobel=None,bn=True, out=args.nmb_cluster) #args.sobel
    fd = int(model.top_layer.weight.size()[1])
    model.top_layer = None
    model.features1 = torch.nn.DataParallel(model.features1)
    model.features2 = torch.nn.DataParallel(model.features2)
    model.features3 = torch.nn.DataParallel(model.features3)
    model.cuda()
    
    cudnn.benchmark = True

    # create optimizer
    optimizer = torch.optim.SGD(
        model.parameters(),
        lr=args.lr,
        momentum=args.momentum,
        #weight_decay= args.wd,
    )
   
    # define loss function
    criterion = nn.CrossEntropyLoss().cuda()
    
    # optionally resume from a checkpoint
    if args.resume:
        if os.path.isfile(args.resume):
            print("=> loading checkpoint '{}'".format(args.resume))
            checkpoint = torch.load(args.resume)
            args.start_epoch = checkpoint['epoch']
            # remove top_layer parameters from checkpoint
            for key in list(checkpoint['state_dict']):
                if 'top_layer' in key:
                    del checkpoint['state_dict'][key]
            model.load_state_dict(checkpoint['state_dict'])
            optimizer.load_state_dict(checkpoint['optimizer'])
            print("=> loaded checkpoint '{}' (epoch {})"
                  .format(args.resume, checkpoint['epoch']))
        else:
            print("=> no checkpoint found at '{}'".format(args.resume))

    # creating checkpoint repo
    exp_check = os.path.join(args.exp, 'checkpoints')
    if not os.path.isdir(exp_check):
        os.makedirs(exp_check)

    # creating cluster assignments log
    cluster_log = Logger(os.path.join(args.exp, 'clusters'))

    # preprocessing of data
    normalize = transforms.Normalize(mean=[0.5, 0.5, 0.5],
                                     std=[0.5, 0.5, 0.5])
    tra = [#transforms.Resize(9),
           #transforms.CenterCrop(9),
           transforms.ToTensor(),
           normalize
          ]

    # load the data

    end = time.time()
    dataset=mydataset.MyDataset(label,args.data, transform=transforms.Compose(tra))

    if args.verbose: print('Load dataset: {0:.2f} s'.format(time.time() - end))
    dataloader = DataLoader(dataset,       #torch.utils.data.
                            batch_size=args.batch,#args.batch
                            num_workers=args.workers,
                            pin_memory=True
                            )
    print (len(dataloader))
    # clustering algorithm to use
    deepcluster = clustering.__dict__[args.clustering](args.nmb_cluster)

    eval_loss_list = []
    eval_acc_list = []
    #loss_reassign = 0.0
    # training convnet with DeepCluster
    for epoch in range(args.start_epoch, args.epochs):
        end = time.time()
        
        # remove head
        model.top_layer = None
        model.classifier = nn.Sequential(*list(model.classifier.children())[:-1])

        # get the features for the whole datasetimages_lists_accurate
        features = compute_features(dataloader,model, len(dataset))
      
        # cluster the features   nmb_cluster_list[epoch] args.nmb_cluster
        acc = deepcluster.cluster(features,label,epoch,args.lr,verbose=args.verbose)
        #clustering_loss = deepcluster.cluster(features,import torch.nn.functional as Fverbose=args.verbose)    
        clustering_loss = 0.0

        if epoch == 0:
          #assign pseudo-labels
          train_dataset = clustering.cluster_assign(deepcluster.images_lists,
                                                  dataset.imgs)

          sampler = UnifLabelSampler(int(args.reassign * len(train_dataset)),
                                  deepcluster.images_lists)

          train_dataloader = torch.utils.data.DataLoader(
              train_dataset,
              batch_size=args.batch,
              shuffle=False,
              num_workers=args.workers,
              sampler=sampler,
              pin_memory=True,
          )
          print ("deep cluster---")
          #sprint (len(deepcluster.images_lists))
          #print (len(deepcluster.images_lists))
        # set last fully connected layer
        mlp = list(model.classifier.children())
        #mlp.append(nn.Batchorm2d(32))
        mlp.append(nn.ReLU(inplace=True).cuda())
        #mlp.append(nn.ReLU(inplace=True))
        model.classifier = nn.Sequential(*mlp)
        model.top_layer = nn.Linear(fd, len(deepcluster.images_lists))
        model.top_layer.weight.data.normal_(0, 0.01)
        model.top_layer.bias.data.zero_()
        model.top_layer.cuda()
       
        #print ("***************************")
        #print (len(train_dataloader))
        #print (train_dataloader)
        # train network with clusters as pseudo-labels
        end = time.time()

        #learning_rate_decay(criterion1,epoch,args.lr)
        #adjust_learning_rate(optimizer, epoch)
        loss = train(train_dataloader, model, criterion, optimizer, epoch)

        #loss_reassign = loss
        #predicted_result = test(dataloader, model, len(dataset),epoch)args.nmb_cluster
        #calcu_changemap_predict(predicted_result,label,p_net-main",epoch,args.lr,args.reassign)

        # save testint result...
        eval_loss_list.append(loss)
        eval_acc_list.append(acc)
 
        #rearranging labels
        #print ("------------------")
        #print (deepcluster.images_lists)
        # print log
        if args.verbose:
            print('###### Epoch [{0}] ###### \n'
                  'Time: {1:.3f} s\n'
                  'Clustering loss: {2:.3f} \n'
                  'ConvNet loss: {3:.3f}'
                  .format(epoch,time.time() - end, clustering_loss, loss))
            try:
                nmi = normalized_mutual_info_score(
                    clustering.arrange_clustering(deepcluster.images_lists),
                    clustering.arrange_clustering(cluster_log.data[-1])
                )
                #print (cluster_log.data)
                print('NMI against previous assignment: {0:.3f}'.format(nmi))
            except IndexError:
                pass
            print('####################### \n')
        # save running checkpoint
        torch.save({'epoch': epoch + 1,
                    'arch': args.arch,
                    'state_dict': model.state_dict(),
                    'optimizer' : optimizer.state_dict()},
                   os.path.join(args.exp, 'checkpoint.pth.tar'))

        # save cluster assignments
        cluster_log.log(deepcluster.images_lists)
     
    plot_acc_loss(eval_loss_list, eval_acc_list,args.nmb_cluster)
    plot_loss(eval_loss_list,args.nmb_cluster)
    #---------------testing outout 2 classes---------------
    #print ('calculate final binary change map---------------')
    #calcu_changemap(deepcluster.images_lists)
    #predicted_result = test(dataloader, model, len(dataset))
    #calcu_changemap_predict(predicted_result,args.epochs,"final_prected_output")

def plot_acc_loss(loss, acc,nmb_cluster):
    host = host_subplot(111)  # row=1 col=1 first pic
    plt.subplots_adjust(right=0.8)  # ajust the right boundary of the plot window
    par1 = host.twinx()   # 共享x轴
 
    # set labels
    host.set_xlabel("Epoch")
    host.set_ylabel("Loss")
    par1.set_ylabel("Accuracy(Kappa)")
 
    # plot curves
    p1, = host.plot(range(len(loss)), loss, label="loss")
    p2, = par1.plot(range(len(acc)), acc, label="accuracy")
 
    # set location of the legend,
    # 1->rightup corner, 2->leftup corner, 3->leftdown corner
    # 4->rightdown corner, 5->rightmid ...
    host.legend(loc=5)
 
    # set label color
    host.axis["left"].label.set_color(p1.get_color())
    par1.axis["right"].label.set_color(p2.get_color())
 
    # set the range of x axis of host and y axis of par1
    # host.set_xlim([-200, 5200])
    # par1.set_ylim([-0.1, 1.1])
    plt.grid()  # 生成网格
    plt.draw()
    plt.savefig("./result_save/SAM/c%s/plt_acc_loss.eps"%(nmb_cluster))
    plt.savefig("./result_save/SAM/c%s/plt_acc_loss.png"%(nmb_cluster))
    #plt.show()
def plot_loss(loss,nmb_cluster):
    host = host_subplot(111)  # row=1 col=1 first pic
    plt.subplots_adjust(right=0.8)  # ajust the right boundary of the plot window
    par1 = host.twinx()   # 共享x轴
 
    # set labels
    host.set_xlabel("Epoch")
    host.set_ylabel("Loss")
    #par1.set_ylabel("Accuracy(Kappa)")
 
    # plot curves
    p1, = host.plot(range(len(loss)), loss)
    #p2, = par1.plot(range(len(acc)), acc, label="accuracy")
 
    # set location of the legend,
    # 1->rightup corner, 2->leftup corner, 3->leftdown corner
    # 4->rightdown corner, 5->rightmid ...
    host.legend(loc=5)
 
    # set label color
    host.axis["left"].label.set_color(p1.get_color())
    #par1.axis["right"].label.set_color(p2.get_color())
 
    # set the range of x axis of host and y axis of par1
    # host.set_xlim([-200, 5200])
    # par1.set_ylim([-0.1, 1.1])
    plt.grid()  # 生成网格
    plt.draw()
    plt.savefig("./result_save/SAM/c%s/plt_loss.eps"%(nmb_cluster))
    plt.savefig("./result_save/SAM/c%s/plt_loss.png"%(nmb_cluster))
    #plt.show()
def adjust_learning_rate(optimizer, epoch):
    """Sets the learning rate to the initial LR decayed by 10 every 30 epochs"""
    lr = args.lr * (0.1 ** (epoch // 1))
    #lr = args.lr +  (0.001 ** (epoch // 2))
    if epoch < 50:
      lr = 0.01
    else:
      lr = 0.01
    print ("lr---------------",lr)
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr
   
def calcu_changemap(i1,images_labels_lists): 
    print ('calcu_changemap-------------------')

    rows,cols = i1.shape
    pseudolabels = np.zeros((rows*cols,1))
    
    for cluster, images in enumerate(images_labels_lists):
        #images = np.array(images)
        for i in range(len(images)):
            pseudolabels[images[i],:] = cluster 
    print (pseudolabels.shape)
    pseudolabels = pseudolabels.reshape(i1.shape)

    print ('======================evaluate predicted===============')
    kappa0 = kappa(pseudolabels, i1/255)
    kappa1 = kappa(np.abs(1-pseudolabels), i1/255)
    #print (B_labels)
    output = pseudolabels
    print (np.max(output))
    print (np.min(output))
    output = output.reshape(i1.shape)
    max_x= np.max(output)
    min_x= np.min(output)
    output = (output - min_x)/(max_x-min_x)*255
    output = Image.fromarray(output.astype(np.uint8))
    output.save("./result_save/SAM/cluster_output_%.4f_%.4f.png" % (kappa0,kappa1))    
    #output.save("/home/donghuihui/change_detection/deepcluster-master-multiscale2/result_save/cluster_output.bmp")    

def kappa(TI, RI): #testData表示要计算的数据，k表示数据矩阵的是k*k的
    m,n = TI.shape
    #将图像转化为列向量
    
    TN = (RI==0) & (TI==0)
    TN = float(np.sum(TN==True))

    TP = (RI!=0) & (TI!=0)
    TP = float(np.sum(TP==True))

    FP = (RI==0) & (TI!=0)
    FP = float(np.sum(FP==True))

    FN = (RI!=0) & (TI==0)
    FN = float(np.sum(FN==True))

    Nc = FN + TP
    Nu = FP + TN
    OE = FP + FN;
    PRA = (TP+TN)/(m*n);
    PRE = ((TP+FP)*Nc+(FN+TN)*Nu)/(m*n)**2;

    #计算相同的比率KC
    KC = (PRA-PRE)/(1-PRE)
    print ('===evaluate====\n'
           'TN:{0} '
           'TP:{1} '
           'FP:{2} '
           'FN:{3} '
           'OE:{4} '
           'KC:{5} '.format(TN,TP,FP,FN,OE,KC))  
    return KC

def train(loader, model, crit,opt,epoch):
    """Training of the CNN.
        Args:
            loader (torch.utils.data.DataLoader): Data loader
            model (nn.Module): CNN
            crit (torch.nn): loss
            opt (torch.optim.SGD): optimizer for every parameters with True
                                   requires_grad in model except top layer
            epoch (int)
    """
    print ('train-------------------')
    batch_time = AverageMeter()
    losses = AverageMeter()
    data_time = AverageMeter()
    forward_time = AverageMeter()
    backward_time = AverageMeter()

    # switch to train mode
    model.train()
    #print (len(loader))
    # create an optimizer for the last fc layer
    optimizer_tl = torch.optim.SGD(
        model.top_layer.parameters(),
        lr=args.lr,
        #weight_decay=args.wd,
    )
    #scheduler = lr_scheduler.StepLR(optimizer4nn, 20, gamma=0.8)
    #optimizer_tl = adabound.AdaBound(model.parameters(), lr=args.lr, final_lr=0.01)
    #optimizer_tl = torch.optim.Adam(model.top_layer.parameters(), lr=args.lr)

    end = time.time()
    for i, (input_tensor1,input_tensor2,input_tensor3,input_tensor4,input_tensor5,input_tensor6,target) in enumerate(loader):
        data_time.update(time.time() - end)

        # save checkpoint
        n = len(loader) * epoch + i
        if n % args.checkpoints == 0:
            path = os.path.join(
                args.exp,
                'checkpoints',
                'checkpoint_' + str(n / args.checkpoints) + '.pth.tar',
            )
            if args.verbose:
                print('Save checkpoint at: {0}'.format(path))
            torch.save({
                'epoch': epoch + 1,
                'arch': args.arch,
                'state_dict': model.state_dict(),
                'optimizer' : opt.state_dict()
            }, path)

        target = target.cuda()
        #input_var = torch.autograd.Variable(input_tensor.cuda())
        input_var1 = torch.autograd.Variable(input_tensor1.cuda())
        input_var2 = torch.autograd.Variable(input_tensor2.cuda())
        input_var3 = torch.autograd.Variable(input_tensor3.cuda())
        input_var4 = torch.autograd.Variable(input_tensor4.cuda())
        input_var5 = torch.autograd.Variable(input_tensor5.cuda())
        input_var6 = torch.autograd.Variable(input_tensor6.cuda())
        target_var = torch.autograd.Variable(target)

        output = model(input_var1,input_var2,input_var3,input_var4,input_var5,input_var6)

        loss = crit(output, target_var) #torch.sub(target_var,0.1)
       
        losses.update(loss.item(), input_tensor1.size(0))

        # compute gradient and do SGD step
        opt.zero_grad()
        #opt4center.zero_grad()
        optimizer_tl.zero_grad()
        loss.backward()
        opt.step()
        #opt4center.step()
        optimizer_tl.step()
    
        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()
        
        if args.verbose and (i % 20) == 0:
            #print (model.attn1.gamma.mean().item())
            print('Epoch: [{0}][{1}/{2}]\t'
                  'Time: {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                  'Data: {data_time.val:.3f} ({data_time.avg:.3f})\t'
                  'Loss: {loss.val:.4f} ({loss.avg:.4f})'
                  .format(epoch, i, len(loader), batch_time=batch_time,
                          data_time=data_time, loss=losses))
   
    return losses.avg

def compute_features(dataloader, model, N):
    torch.backends.cudnn.enabled = False
    if args.verbose:
        print('Compute features')
    batch_time = AverageMeter()
    end = time.time()
    model.eval()
    total_feature = []
    # discard the label information in the dataloader
    for i, (input_tensor1,input_tensor2,input_tensor3,input_tensor4,input_tensor5,input_tensor6,target) in enumerate(dataloader):
        #input_var = torch.autograd.Variable(input_tensor.cuda(), volatile=True)
        """print ('input_tensor.size-----------B_labels = B.reshape(i1.shape)

    print ('======================evaluate predicted===============')
    kappa0 = kappa(B_labels, i1/255)
    kappa1 = kappa(np.abs(1-B_labels), i1/255)-')
        print (input_tensor1.shape)#torch.Size([100, 3, 32, 32]),([batchsize,channel,H,W])
        print (input_tensor2.shape)#torch.Size([100, 3, 32, 32])
        print (target.shape)#torch.Size([100, 3, 32, 32])"""
        input_var1 = torch.autograd.Variable(input_tensor1.cuda(),volatile=True)
        input_var2 = torch.autograd.Variable(input_tensor2.cuda(),volatile=True)
        input_var3 = torch.autograd.Variable(input_tensor3.cuda(),volatile=True)
        input_var4 = torch.autograd.Variable(input_tensor4.cuda(),volatile=True)
        input_var5 = torch.autograd.Variable(input_tensor5.cuda(),volatile=True)
        input_var6 = torch.autograd.Variable(input_tensor6.cuda(),volatile=True)
        #feature, pred = model(input_var1,input_var2,input_var3,input_var4,input_var5,input_var6)
        aux = model(input_var1,input_var2,input_var3,input_var4,input_var5,input_var6)
        aux = aux.cpu().detach().numpy()
        if i == 0:
            features = np.zeros((N, aux.shape[1])).astype('float32')

        if i < len(dataloader) - 1:
            features[i * args.batch: (i + 1) * args.batch] = aux.astype('float32')
        else:
            # special treatment for final batch
            features[i * args.batch:] = aux.astype('float32')
        #total_feature.append(feature.data.cpu())

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        if args.verbose and (i % 20) == 0:
            print('{0} // {1}\t'
                  'Time: {batch_time.val:.3f} ({batch_time.avg:.3f})'
                  .format(i, len(dataloader), batch_time=batch_time))
    #total_feature = torch.cat(total_feature, dim=0)
    #total_feature = total_feature.numpy()    

    return features

def calcu_changemap_predict(B,i1,temp,epoch,lr,nmb_cluster): 
    print ('calcu_changemap_predict-------------------')
    #farmlandD
    rows,cols = i1.shape
    print (np.max(B))
    print (np.min(B))
    #i1 = i1.T
    B_labels = B.reshape(i1.shape)
    output_medfilt = signal.medfilt(B_labels,kernel_size=3)

    print ('======================evaluate predicted===============')
    kappa0 = kappa(B_labels, i1/255)
    kappa1 = kappa(np.abs(1-B_labels), i1/255)

    max_x= np.max(B_labels)
    min_x= np.min(B_labels)
    B_labels = (B_labels - min_x)/(max_x-min_x)*255
    print ('io===============')
    #dst.save("/home/donghuihui/Pytorch/%s_%s.jpg" % ('rgb',temp)) 
    B_labels = Image.fromarray(B_labels.astype('uint8'))
    #dst  =color.label2rgb(B_labels)
    #io.imshow(dst)
    #B_labels = skimage.img_as_float(B_labels).dtype
    B_labels.save("./result_save/SAM/%s_%s_%s_%s_%.4f_%.4f.png" % (temp,epoch,lr,nmb_cluster,kappa0,kappa1))    
    
    kappa0 = kappa(output_medfilt, i1/255)
    kappa1 = kappa(np.abs(1-output_medfilt), i1/255)
    max_x= np.max(output_medfilt)
    min_x= np.min(output_medfilt)
    output_medfilt = (output_medfilt - min_x)/(max_x-min_x)*255

    output_medfilt = Image.fromarray(output_medfilt.astype(np.uint8))
    output_medfilt.save("./result_save/SAM/medfilt_%s_%s_%s_%s_%.4f_%.4f.png" % (temp,epoch,lr,nmb_cluster,kappa0,kappa1)) 
def test(dataloader, model, N,epoch):
    if args.verbose:
        print('testing-------------------')
    batch_time = AverageMeter()
    end = time.time()
    model.eval()
    total_pred_label = []
    total_target = []
    total_feature = []
    # discard the label information in the dataloader
    for i, (input_tensor1,input_tensor2,input_tensor3,input_tensor4,input_tensor5,input_tensor6,target) in enumerate(dataloader):
        input_var1 = torch.autograd.Variable(input_tensor1.cuda(),volatile=True)
        input_var2 = torch.autograd.Variable(input_tensor2.cuda(),volatile=True)
        input_var3 = torch.autograd.Variable(input_tensor3.cuda(),volatile=True)
        input_var4 = torch.autograd.Variable(input_tensor4.cuda(),volatile=True)
        input_var5 = torch.autograd.Variable(input_tensor5.cuda(),volatile=True)
        input_var6 = torch.autograd.Variable(input_tensor6.cuda(),volatile=True)
        aux = model(input_var1,input_var2,input_var3,input_var4,input_var5,input_var6).data.cpu().numpy()
        pred  = np.argmax(aux,1)
         #100*32
        if i == 0:
            features = np.zeros((N))#.astype('float32')
            #print (pred)
        if i < len(dataloader) - 1:
            features[i * args.batch: (i + 1) * args.batch] = pred#.astype('float32')
        else:
            # special treatment for final batch
            features[i * args.batch:] = pred#.astype('float32')

        """total_pred_label.append(pred_label.data.cpu())
        total_target.append(target.data.cpu())
        total_feature.append(feature.data.cpu())"""

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()
    #features = features.reshape((features.shape[0],1))  

    """total_pred_label = torch.cat(total_pred_label, dim=0)
    total_target = torch.cat(total_target, dim=0)
    total_feature = torch.cat(total_feature, dim=0)

    total_target = total_target.long()
    #total_pred_label = torch.LongTensor(total_pred_label)
    print (total_pred_label.shape)
    print (total_target.shape)

    precision = torch.sum(total_pred_label == total_target).item() / float(total_target.shape[0])
    print("Validation accuracy: {}%".format(precision * 100))
    
    scatter(total_feature.numpy(), total_target.numpy(), epoch)"""

    #return total_pred_label.numpy()
    return features

def scatter(feat, label, epoch):
    plt.ion()
    plt.clf()
    palette = np.array(sns.color_palette('hls', args.nmb_cluster))
    ax = plt.subplot(aspect='equal')
    # sc = ax.scatter(feat[:, 0], feat[:, 1], lw=0, s=40, c=palette[label.astype(np.int)])
    for i in range(args.nmb_cluster):
        plt.plot(feat[label == i, 0], feat[label == i, 1], '.', c=palette[i])
    plt.legend(['0', '1', '2', '3', '4'], loc='upper right') #'5', '6', '7', '8', '9'
    ax.axis('tight')
    for i in range(args.nmb_cluster):
        xtext, ytext = np.median(feat[label == i, :], axis=0)
        txt = ax.text(xtext, ytext, str(i), fontsize=18)
        txt.set_path_effects([PathEffects.Stroke(linewidth=5, foreground="w"), PathEffects.Normal()])

    plt.draw()
    plt.savefig('./benchmark/centerloss_{}.png'.format(epoch))
    plt.pause(0.001)

if __name__ == '__main__':
   
    warnings.filterwarnings('ignore')
    main()
